﻿Responsive HTML5 Template

Exotic tours and travels bootstrap template is a multi-purpose clean html5 template built with valid HTML5 & CSS3. The design is very flat and modern look, full-fill with latest standards, It's based on latest Bootstrap framework 3.3.1 fully responsive web compatible with multi browser and devices. This template can be used for multi-purpose needs also like business, consultancy, agency, personal portfolio, profile, mobile website and start-up company.

Key features
-------------
Twitter Bootstrap 3.3.1
Clean & Developer-friendly HTML5 and CSS3 code
100% Responsive Layout Design 
Multi-purpose theme
Google Fonts Support
Font Awesome 
Smooth Scrolling 
Fully Customizable
Contact Form


Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com
=> Photos used in template: **Unsplash** - http://unsplash.com, http://risewall.com/home-business-team-wallpapers.html, http://www.freestockphotos.name/
=> For more free web themes: http://webthemez.com
=> Framework : http://getbootstrap.com

Important Note:
---------------
To remove backlink from the template, you need to donate to remove the backlink from the template.
Any question contact us: webthemez@gmail.com


License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/

- You are allowed to use all files for both personal and commercial projects.

- If you use/modify the resources in your projects,we’d appreciate a linkback to this site.

- You do not have rights to redistribute,resell or offer files from this site to any third party

- If you wish to remove backlink from the template, you need to donate min USD $10 to remove backlink (credits) form the template

- If you have any question,feel free to contact us at webthemez@gmail.com

- All images user here is for demo purpose only, we are not responsible for any copyrights.
