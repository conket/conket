eLearning - Free Educational Responsive Web Template
-------
eLearning is a free, responsive, modern-looking educational template based on Bootstrap HTML/CSS framework. 

Features :
--------
=> Easy to use, Heigh quality coded HTML5 and CSS3.
=> Multi device compatibility
=> Responsive design with bootstrap
=> premium quality template

Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com
=> Photos used in template: **Unsplash** - http://unsplash.com
=> For more free web themes: http://webthemez.com
=> Framework : http://getbootstrap.com
=> Image: we are not responsible for copyrights issues, please change asper your needs

License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/
**Note: Please dont remove the backlink (Template by: webthemez.com) in the footer.
