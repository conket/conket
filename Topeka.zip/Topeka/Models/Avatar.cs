﻿namespace Topeka
{
	public enum Avatar {
		One = Resource.Drawable.avatar_1,
		Two = Resource.Drawable.avatar_2,
		Three = Resource.Drawable.avatar_3,
		Four = Resource.Drawable.avatar_4,
		Five = Resource.Drawable.avatar_5,
		Six = Resource.Drawable.avatar_6,
		Seven = Resource.Drawable.avatar_7,
		Eight = Resource.Drawable.avatar_8,
		Nine = Resource.Drawable.avatar_9,
		Ten = Resource.Drawable.avatar_10,
		Eleven = Resource.Drawable.avatar_11,
		Twelve = Resource.Drawable.avatar_12,
		Thirteen = Resource.Drawable.avatar_13,
		Fourteen = Resource.Drawable.avatar_14,
		Fifteen = Resource.Drawable.avatar_15,
		Sixteen = Resource.Drawable.avatar_16
	}
}

